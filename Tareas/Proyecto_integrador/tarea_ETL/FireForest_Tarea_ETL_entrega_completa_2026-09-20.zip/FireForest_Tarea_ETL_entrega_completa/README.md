# Tarea ETL - FireForest

## Objetivo y alcance

Construir un flujo ETL reproducible que integre la malla espacial, la evidencia
mensual de incendios VIIRS y la precipitacion CHIRPS para estudiar su relacion
en el canton Loja durante 2023. La poblacion comprende 7.997 celdas de 500 m x
500 m observadas durante 12 meses. La unidad final es una celda-mes y su clave
es `cell_id + anio + mes`.

El flujo conserva Raw, estandariza cada fuente en Clean y realiza una union uno
a uno por `cell_index + anio + mes` para construir Curated.

## Contenido de la entrega

- `raw/malla/malla_500m_loja_maestra.gpkg`: geometria de 7.997 celdas.
- `clean/`: fuentes 2023 tipadas, excepciones y rechazos.
- `curated/fireforest_celda_mes_2023.csv`: dataset integrado de 45 variables.
- `curated/diccionario_datos.csv`: significado, tipo, unidad y derivacion.
- `codigo/`: scripts del perfilado, calidad y ETL completo.
- `configuracion/`: parametros, reglas, transformaciones y dependencias.
- `evidencias/`: diagnostico, controles, comparacion y bitacora exigidos.

## Fuentes Raw y procedencia

La malla GeoPackage se incluye porque es pequena y permite inspeccionar la
geometria. Los CSV Raw historicos 2019-2025 de VIIRS y CHIRPS superan los 100 MB
cada uno y no se duplican en esta entrega. Su procedencia, ruta controlada,
tamano y SHA-256 constan en `raw/metadatos/manifiesto_firelab_loja.json`.

Los resultados Clean y Curated de 2023 incluidos permiten revisar el flujo. La
reproduccion desde Raw requiere obtener las dos fuentes historicas registradas
en el manifiesto y ubicarlas en las rutas indicadas por
`configuracion/perfilado.json`.

## Ejecucion

Dependencias:

```powershell
python -m pip install -r configuracion/requirements_etl.txt
```

Desde la raiz del repositorio FireForest, con las fuentes Raw disponibles:

```powershell
.venv\Scripts\python.exe Tareas\Proyecto_integrador\tarea_ETL\codigo\etl_fireforest.py --desde-cero
```

`etl_fireforest.py --desde-cero` ejecuta en orden
`perfilar_fuentes.py`, `evaluar_calidad_raw.py` y la construccion de Clean y
Curated. Una regla critica detiene el flujo; los registros no aptos se separan
o se conservan con una bandera explicita.

## Transformaciones e integracion

1. Seleccion reproducible del periodo 2023.
2. Tipado de identificadores, numeros, fechas y booleanos.
3. Normalizacion espacial mediante `cell_index` y `cell_id`.
4. Banderas de cobertura y aptitud analitica.
5. Calculo de la fraccion de dias humedos.
6. Marcado IQR de valores atipicos sin eliminarlos.

La integracion valida una cardinalidad uno a uno antes de unir VIIRS y CHIRPS.
Se conservan las claves esperadas y los faltantes VIIRS no se convierten en
cero.

## Resultados y controles

- Malla CSV: 7.997 filas.
- VIIRS Clean: 95.964 filas.
- CHIRPS Clean: 95.964 filas.
- Curated: 95.964 filas.
- 95.064 filas aptas para analisis y 900 sin observacion VIIRS.
- 16 controles Clean y 11 controles Curated cumplidos.
- Cero duplicados en la clave final.
- SHA-256 de la malla GeoPackage: `fccff14a88ead66340b339a9463f0e56ff78f1bedd23decd600936e1e4d177a4`.

La evidencia se concentra en nueve archivos: perfilado de columnas y claves,
estadisticas de atipicos, matriz de calidad, comparacion antes y despues,
controles Clean y Curated, bitacora de decisiones y prueba de reproducibilidad.

## Conclusiones y limitaciones

- La union conserva 95.964 observaciones celda-mes sin multiplicar registros.
- Los valores atipicos se marcan y conservan porque pueden representar eventos
  ambientales reales.
- Las 900 filas sin VIIRS permanecen como nulas y no se interpretan como
  ausencia de incendio.
- VIIRS y CHIRPS llegan agregados por mes; no permiten reconstruir eventos
  diarios ni establecer causalidad entre lluvia y fuego.
