# Tarea ETL - FireForest

## Objetivo y alcance

Construir un flujo ETL reproducible que integre la malla espacial, la evidencia
mensual de incendios VIIRS y la precipitacion CHIRPS para estudiar su relacion
en el canton Loja durante 2023. La poblacion comprende 7.997 celdas de 500 m x
500 m observadas durante 12 meses. La unidad final es una celda-mes y su clave
es `cell_id + anio + mes`.

El flujo conserva Raw, estandariza cada fuente en Clean y realiza una union uno
a uno por `cell_index + anio + mes` para construir Curated.

## Contenido ejecutable de la entrega

- `Proyecto_integrador/02_datos/raw/`: malla y subconjuntos VIIRS/CHIRPS 2023.
- `Proyecto_integrador/tarea_ETL/clean/`: fuentes tipadas y excepciones.
- `Proyecto_integrador/tarea_ETL/curated/`: dataset final y diccionario.
- `Proyecto_integrador/tarea_ETL/codigo/`: los tres scripts del flujo completo.
- `Proyecto_integrador/tarea_ETL/configuracion/`: parametros y dependencias.
- `Proyecto_integrador/tarea_ETL/evidencias/`: pruebas exigidas por la guia.

## Fuentes Raw y procedencia

El paquete incluye la malla completa y las 95.964 filas Raw de 2023 de cada
fuente mensual. No duplica los historicos 2019-2025. Los subconjuntos conservan
las columnas y valores originales; solo aplican el filtro `anio == 2023`.

- VIIRS Raw 2023: 95.964 filas, SHA-256
  `b96f41f61959496647a8fa95dae92d996f27107441372f99c674f76ff1182fd2`.
- CHIRPS Raw 2023: 95.964 filas, SHA-256
  `1b3864de095a6eda1f0bd4d9027ee05c2054d0df1b1147dde9cec68473f153c6`.

La procedencia, el hash de cada fuente historica y el hash de cada subconjunto
se registran en
`Proyecto_integrador/05_ingesta/metadatos/manifiesto_firelab_loja.json`.

## Ejecucion

Abra una terminal en la carpeta extraida y ejecute:

```powershell
cd Proyecto_integrador
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r tarea_ETL\configuracion\requirements_etl.txt
.venv\Scripts\python.exe tarea_ETL\codigo\etl_fireforest.py --desde-cero
```

`etl_fireforest.py --desde-cero` ejecuta en orden
`perfilar_fuentes.py`, `evaluar_calidad_raw.py` y la construccion de Clean y
Curated. Una regla critica detiene el flujo; los registros no aptos se separan
o se conservan con una bandera explicita.

## Transformaciones e integracion

1. Seleccion reproducible del periodo 2023.
2. Tipado de identificadores, numeros, fechas y booleanos.
3. Normalizacion espacial mediante `cell_index` y `cell_id`.
4. Banderas de cobertura y aptitud analitica.
5. Calculo de la fraccion de dias humedos.
6. Marcado IQR de valores atipicos sin eliminarlos.

La integracion valida una cardinalidad uno a uno antes de unir VIIRS y CHIRPS.
Se conservan las claves esperadas y los faltantes VIIRS no se convierten en
cero.

## Resultados y controles

- Malla CSV: 7.997 filas.
- VIIRS Clean: 95.964 filas.
- CHIRPS Clean: 95.964 filas.
- Curated: 95.964 filas.
- 95.064 filas aptas para analisis y 900 sin observacion VIIRS.
- 16 controles Clean y 11 controles Curated cumplidos.
- Cero duplicados en la clave final.
- SHA-256 de la malla GeoPackage: `fccff14a88ead66340b339a9463f0e56ff78f1bedd23decd600936e1e4d177a4`.

La evidencia se concentra en nueve archivos: perfilado de columnas y claves,
estadisticas de atipicos, matriz de calidad, comparacion antes y despues,
controles Clean y Curated, bitacora de decisiones y prueba de reproducibilidad.

## Conclusiones y limitaciones

- La union conserva 95.964 observaciones celda-mes sin multiplicar registros.
- Los valores atipicos se marcan y conservan porque pueden representar eventos
  ambientales reales.
- Las 900 filas sin VIIRS permanecen como nulas y no se interpretan como
  ausencia de incendio.
- VIIRS y CHIRPS llegan agregados por mes; no permiten reconstruir eventos
  diarios ni establecer causalidad entre lluvia y fuego.
