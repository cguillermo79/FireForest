# LEEME PRIMERO

Este paquete permite revisar la entrega ETL de FireForest sin depender de las
carpetas locales del equipo.

## Archivos principales

- `raw/malla/malla_500m_loja_maestra.gpkg`: geometria de 7.997 celdas.
- `clean/malla_500m.csv`: atributos tabulares de la malla.
- `clean/viirs_2023.csv`: VIIRS Clean de 2023.
- `clean/chirps_2023.csv`: CHIRPS Clean de 2023.
- `curated/fireforest_celda_mes_2023.csv`: dataset analitico integrado.
- `curated/diccionario_datos.csv`: definicion de las variables.

Los mismos productos tambien se incluyen en Parquet cuando existe esa salida.

## Verificaciones realizadas antes de crear el ZIP

- Malla CSV: 7.997 filas.
- VIIRS Clean: 95.964 filas.
- CHIRPS Clean: 95.964 filas.
- Curated: 95.964 filas.
- No existen claves duplicadas en los cuatro productos anteriores.
- SHA-256 de la malla GeoPackage: `fccff14a88ead66340b339a9463f0e56ff78f1bedd23decd600936e1e4d177a4`.

## Alcance de Raw

Los CSV Raw historicos 2019-2025 de VIIRS y CHIRPS no se duplican en este ZIP.
El paquete contiene sus productos Clean de 2023, el dataset Curated y las
evidencias necesarias para evaluarlos. La procedencia y los hashes de los Raw
se documentan en `raw/metadatos/manifiesto_firelab_loja.json`.

Por esta razon, el ZIP es autocontenido para revision y analisis de los
resultados, pero la reproduccion desde Raw requiere acceso controlado a las
fuentes originales descritas en el manifiesto.
